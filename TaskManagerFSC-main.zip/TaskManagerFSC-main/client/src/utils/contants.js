const USERS_URL = "/user";

const TASKS_URL = "/task";

const ADMIN_URL = "/admin";

export { USERS_URL, TASKS_URL, ADMIN_URL };
